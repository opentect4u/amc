<?php
	$mm_parts = "select sl_no,parts_desc from mm_parts";
	$parts_result = mysqli_query($conn,$mm_parts);
?>