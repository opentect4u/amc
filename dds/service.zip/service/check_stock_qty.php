<?php
	require '../../lib/connection.php';

	$comp_no = $_GET['comp_no'];
	$servArea = $_GET['serv_area'];
	$mm_parts = "SELECT parts_desc FROM mm_parts WHERE sl_no = $comp_no";
	$parts_result = mysqli_query($conn, $mm_parts);
	$stk_quantity = 0;
	$result = mysqli_fetch_assoc($parts_result);
	$comp_name = $result['parts_desc'];

	//echo $parts_desc;

	$sql = "SELECT stk_quantity
				   		  FROM gm_stock_balance
				          WHERE comp_name = '$comp_name' 
				          AND serv_area = '$servArea'
				          AND balance_dt = (SELECT MAX(balance_dt) 
							  										  FROM gm_stock_balance 
							  										  WHERE comp_name = '$comp_name') 
				          AND trf_no = (SELECT max(trf_no)
						          								  FROM gm_stock_balance 
						          								  WHERE comp_name = '$comp_name' 
						          								  AND serv_area = '$servArea' 
						          								  AND balance_dt = (SELECT MAX(balance_dt) 
						          								  										  FROM gm_stock_balance 
						          								  										  WHERE comp_name = '$comp_name'))";

	$result = mysqli_query($conn, $sql);

	if ($result) {
		$data = mysqli_fetch_assoc($result);
		$stk_quantity = $data['stk_quantity'];
	}

	echo $stk_quantity;
?>
