<?php require '../../lib/connection.php';?>
<!DOCTYPE html>
<html>
<head>
	<title>SYNERGIC ADD PARTS</title>
	<link rel="icon" href="../../favicon.ico">
<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<div class="header">
		<?php require 'header.php';?>
	</div>
	<div class="nav_holder">
		<?php require 'service_nav.php';?>
	</div>
	<div class= "item_body_container">
	<?php require 'insert_parts.php';?>
	<?php require 'add_parts_body.php';?>
	</div>
</body>