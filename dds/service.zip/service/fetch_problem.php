<?php
	$mm_problem = "select sl_no,problem_desc from mm_problem";
	$problem_result = mysqli_query($conn,$mm_problem);
?>