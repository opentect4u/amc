<?php
	$mm_machine = "select mc_id,mc_type from mm_mc_type";
	$machine_result = mysqli_query($conn,$mm_machine);
?>