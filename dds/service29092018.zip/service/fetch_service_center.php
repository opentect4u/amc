<?php
  $sql = "SELECT * FROM mm_service_center";
  $result = mysqli_query($conn, $sql);
?>
