<div class="item_body">
	<h1>MACHINE PROBLEM</h1>
	<form name="add_user_form" method="POST" action="">
	<table>
		<tr>
			<td>PROBLEM DESCRIPTION</td>
			<td><input type="text" name="problem_desc" class="input_text" onKeyDown="item_typeone()" required /></td>
			<td id ="user_eid"><span style='color: red;'></span></td>
		</tr>
         <tr>

			<td></td>
			<td><input type="submit" value="ADD" class="submit"></td>
			
		</tr>
	</table>
	</form>
</div>
