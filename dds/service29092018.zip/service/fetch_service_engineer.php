<?php

    $sql = "SELECT DISTINCT serv_by FROM td_service_out";

    $result = mysqli_query($conn, $sql);
    
?>